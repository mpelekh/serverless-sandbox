"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const utils_1 = require("./utils");
aws_sdk_1.config.region = process.env.REGION;
const s3 = new aws_sdk_1.S3();
const sqs = new aws_sdk_1.SQS();
module.exports.process = (event) => __awaiter(this, void 0, void 0, function* () {
    console.log("s3 event: ", JSON.stringify(event, null, 2));
    console.log("sqs queue URL: ", process.env.QUEUE_URL);
    const CHUNK_SIZE = 25;
    for (const record of event.Records) {
        try {
            const objectOutput = yield s3
                .getObject({
                Bucket: record.s3.bucket.name,
                Key: record.s3.object.key,
            })
                .promise();
            const todos = JSON.parse(objectOutput.Body.toString("utf-8"));
            const chunks = utils_1.chunk(todos, CHUNK_SIZE);
            yield sendToSQS(chunks);
        }
        catch (err) {
            console.error(err);
        }
    }
});
const sendToSQS = (chunks) => __awaiter(this, void 0, void 0, function* () {
    for (const chunk of chunks) {
        const params = {
            MessageBody: JSON.stringify(chunk),
            QueueUrl: process.env.QUEUE_URL,
        };
        try {
            console.log("trying send ton SQS batch: ", chunks.indexOf(chunk));
            const result = yield sqs.sendMessage(params).promise();
            console.log("success: ", result);
        }
        catch (error) {
            console.error(error);
        }
    }
});
